//*********************************************************************                  
//*                       McMaster University                         *
//*                      2DP4 Microprocessors                         *
//*********************************************************************
//*********************************************************************
//*   FINAL PROJECT- Ezzeldin Tahoun- 400043499- tahoune@mcmaster.ca
//*********************************************************************                  

//***********************************************************************
// Last Modified to : edit main structure + add comments
// by Ezzeldin Tahoun, TIMESTAMP: 11:18 AM 28/03/2016
//***********************************************************************

/* Assigned Values 

Channel AN3       : Pin A3 is used ..  void setReg(void ) does stuff [[ table 11-2 in ref man regarding AN channel and 11-15 regarding sampling on this channel ]] 

Resolution 8 bits : void setReg(void) is the magic sauce [[ table 11.4 ref manual for more info regarding resolution ]] 

Bus Speed 2 MHz   : void setClk(void) does the magic [[ refer to W7-1 lec for more info ]] 

Sampling @ 440 Hz :void setReg(void) is a bless [[ more info regarding sampling in table 11-10 in ref man ]] | delay 2.27 ms which is 1/440 * 1000 ~= 2.3 

*/ 

// BONUS 1 DONE : BUTTON IS IMPLEMENTED AS INTERRUPT ... TIME DELAY IS IMPLEMENTED AS INTERRUPT ( BOTH ARE NEEDED FOR BONUS AS MENTIONED IN LECTURE )


/* Libraries Used */ 
#include <hidef.h>       /* common defines and macros */
#include "derivative.h"  /* derivative information */
#include "SCI.h"         /* serial communication */

/* Functions' Prototypes */
void setClk(void);// sets all my clock/bus speed related stuff 
void setATD(void); // sets all my ATD registers 
void setInterrupts(void); //sets all interrupts settings and PTJ output settings 
void setSCI(unsigned int rate); // sets Baud Rate for SCI 
void OutCRLF(void); // this function acts like a new line character for my serial communications
void delayby100us(int k); // ( delay of 10 micro seconds = 10^-5 second ) * k ; function delays execution for k * 10us 
void SCI_ADC_out (unsigned short ADC_ ); // OUTPUTS the ADC value passed to it 
void delay(int kk); // delay function controls timer overflow interrupts used in Delay 
void Delay(int cc); // Delay 67.647 * 10^-6 seconds 


/* MAIN FN */ 
 unsigned int flag = 0; // GLOBAL VAR // flag to turn the SCI OUTPUT execution ON or OFF [[ altered and controlled by interrupts ]] 
//static is same as global var (so ISR can access) but it keeps the var to this file only (no messing with others).. so no worries 
				unsigned   int counter = 0 ;     unsigned  int k=1000; // GLOBAL VARS used in delay(int) 
void main(void) { // program's entry point 

/* --- program settings *** START *** program settings --- */
setClk(); 			// set clock/bus speed to 2MHz 
setATD(); 			// set ATD registers for configured conversion settings ( 8 bits resolution / AN3 etc. ) 
setInterrupts() ;   // set all Interrupts registers and start listening for them 
setSCI(9600);       // sets Baud Rate (9600) for SCI and smooth serial communication 
/* --- program settings *** END *** program settings --- */

//DisableInterrupts; //CodeWarrior's method of DISabling interrupts

/*
for(;;){ // verify sampling rate and clock speed by pin d13 on oscilloscope 
  PTJ=0x01;   
 //delayby100us(23); 
 Delay(43); 
 PTJ=0x00;   //      delayby100us(23);
 Delay(43);
  }
  */
  
/* --- main loop *** START *** main loop --- */
flag =0;
while (1)  // loop forever !INFINITE LOOPING STRUCTURE!     remove semicolon to loop over the 2 foloowing lines MODE2   // PUT SEMICOLON AFTER WHILE FOR MODE 1


if (flag==1)// execute if flag is 1 otherwise don't 	
		SCI_ADC_out(ATDDR0); // reads value from ATDDR0 and passes it out with sampling rate of 440Hz 

//else  PT1AD =0x00; // turn off red serial communication led connected on pin A0 
/* --- main loop *** END *** main loop --- */

}
unsigned int ez ; 

/* Interrupt Service Routine */
interrupt VectorNumber_Vtimch0 void ISR_Vtimch0(void){ // detects high on pin d2 pt0 
                  


  if ( flag ==1 ) flag = 0 ; 
  else if ( flag == 0 ) flag =1;
  else PTJ =0x01; 
  
//flag^=1; // if true make it false ; else if false make it true ..
//.. in other words it toggles the value of the flag by XORing it with a 1 thus ..
//..  stopping/starting the execution of the SCI ADC module.
//Delay(34000); // random delay 

ez = TC0; // allow another tic 


// FOR MODE 2 ( REMOVING SEMICOLON AFTER WHILE LOOP IN MAIN PLEASE COMMENT OUT ALL THIS LOOP FOLLOWING                           // FOR MODE 1 UNCOMMENT THIS LOOP 
   /*
for(;;){    


if ( flag==1 )   {
ez = TC0; // allow another tic 
  
        
SCI_ADC_out(ATDDR0);
}


if ( flag == 0 ) PT1AD^=0x02;  
}

 */   

// MODE 2 REMOVE THE ABOVE TWO SLASHES TO COMMENT THIS PART OUT SINCE YOU INCLUDED IT IN MAIN INFINITE LOOP BY REMOVING THE SEMICOLON // UNCOMMENT ALL OF THE LOOP ABOVE FR MODE1 

//DisableInterrupts;exit();                     }// reads value from ATDDR0 and passes it out with sampling rate of 440Hz 
//flag=1; // if true make it false ; else if false make it true ..
//.. in other words it toggles the value of the flag by XORing it with a 1 thus ..
//..  stopping/starting the execution of the SCI ADC module.
//Delay(34000); // random delay */
/*ez = TC0; // allow another tic   
flag=1;
PTJ ^= 0x01; // toggle ptj on board led 
Delay(9000);
flag=1; 
PT1AD^=0x02; // toggle green led representing flag and processing mode connected on A1 
  */
}

interrupt VectorNumber_Vtimovf void ISR_Vtimovf(void){ // detects ovf of time 

if ( counter < k) {
    while(!(TFLG1_C3F)); // tc3 stop till its 1 
  //  ez = TFLG1_C3F;
   counter++;
 	TC3 += 200; // tc3
}else  {

  TSCR2 = 0x01;  /* disable timer interrupt, set prescaler to 1*/
    TIOS  &= ~0x08;   

setInterrupts();
}//RESET SETTINGS }


}

/* Functions Used */ 
void setClk(void){ // sets all my clock related stuff 
CPMUPROT = 0x26; // TO ENABLE WRITING TO THE REGS 
 /*     sets up bus clock (2 MHz)  */
 CPMUCLKS = 0x80;  //PLLSEL = 1
 CPMUOSC  = 0x00;  //OSCE = 0s // so we using firc1m which is 1 MHz by default fref = 1 mhz 
 // if osce 1 it would be 8 Mhz but nah we will not use it 
 CPMUSYNR = 0x07;  //VCOFRQ = 0, SYNDIV = 7
 // Now fREF = 1 MHz and fVCO = 2* fREF * (7+1) = 16MHz
 CPMUPOSTDIV = 0x03;
CPMUFLG=0x00; // TO ENSURE CALCULATION IS VALID
 // PLLCLK = fVCO/(3+1) = 4MHz
 // Thus the Bus Clock = 4MHz/2 = 2 !!!!!
}

void setATD(void){ // sets all my ATD registers 
  ATDCTL0 = 0x03;   // wraps to 0 and 3 [ wrap0 & wrap1 are set to 1 while wrap2 and wrap3 are zero indicating AN3 ] 
  ATDCTL1 = 0x0F;   // set for 8-bit resolution sres0 and sres 1 are both zeros 
  ATDCTL3 = 0x88;   // right justified [djm] , one sample per sequence	[ s1c is set ] 
  ATDCTL4 = 0x01;   // prescaler = 1; ATD clock = 2MHz / (2 * (1 + 1)) == 0.5MHz
  ATDCTL5 = 0x23;   // continuous SCAN,  samples only one channel which is an3  cb and ca are set while cc and cd are not 
}

void setInterrupts(void){ //sets all interrupts settings 
DDRJ = 0xFF; //set all port J as output
DDR1AD=0x03; // set b0 as dig output  
TSCR1 = 0x90; //Timer System Control Register 1
TSCR2 = 0x01; //Timer System Control Register 2
TIOS = 0xFE; //Timer Input Capture or Output capture
PERT = 0x01; //Enable Pull-Up resistor on TIC[0]
TCTL3 = 0x00; //TCTL3 & TCTL4 configure which edge(s) to capture
TCTL4 = 0x02; //Configured for falling edge on TIC[0]
TIE = 0x01; //Timer Interrupt Enable
DDRJ |= 0x01; // PortJ bit 0 is output to LED D2 on DIG13
EnableInterrupts; //CodeWarrior's method of enabling interrupts

}; 

void Delay (int cc ) {    //delay of 67.64 micro seconds  
             
                  unsigned    int i;
              for (i=0; i<cc ;i++){
//if ( i % 10 ==0 )               PTJ ^=0x01;// every ten cycles toggle to show 
                
               delay(1);  
 
// delayby100us(23); break; // THIS LINE WILL USE DIFFERENT DELAY METHOD FOR SAME RESULTS (GIVEN IN LECTURE AND MODIFIED TO SUITE MY SETTINGS)
              }
              
              }

void setSCI(unsigned int rate){ // sets Baud Rate for SCI 
SCI_Init(rate); // ASSUMED 9600 default     // start serial communication using a baud rate of 9600 .. 
//.. SBR = ACI Baud control Register = fe /16 / Baud Rate = 2MHz / 16 / 9600 = 13.02 ~= 13 //  SCI0BDH = 0; SCI0BDL=13; so..
//.. we change this is in SCI.c to account for 2 MHz clock we set; found in void SCI_Init(unsigned short baudRate)..
//.. function is a switch case ladder with all values..
//.. we either change em all or just the 9600 case for SCI0BDL=13; to ensure we got SCI0BDH = 0; SCI0BDL=13; to serially communicate.. 
//.. in a correct manner with the PC otherwise garbage would be read on the other side..
/* -- CODE SNIPPET of the Modified Section of the SCI.c file to account for 2Mhz clock we just set 
void SCI_Init(unsigned short baudRate){
  SCI0BDH = 0;   // br=MCLK/(16*baudRate) 
  
  switch(baudRate){
    case 2400:  SCI0BDL=52; break;
    case 4800:  SCI0BDL=26;  break;
    case 19200: SCI0BDL=8;  break;
    default:    SCI0BDL = 13 ;  // 9600 
  }
  ... rest of function SCI_Init 
*/}

void OutCRLF(void){ // this function acts like a new line character for my serial comms
  SCI_OutChar(CR);
  SCI_OutChar(LF);
  //PTJ ^= 0x20;          // toggle LED D2
}

void delayby100us(int k){ // delay of 100 micro seconds = 10^-4 second OLD NOT USED 
      int ix;
	  //int delayy = 20 ;// should be 2000 HOWEVER I am passing 2.27 according to my sampling rate but this will be 2 instead of 2.37 a way around this is to make that 2000 a 20 and pass 227 for more precision and accuracy ... thus the function would be a delay of 10^-4 seconds 
      TSCR1 = 0x90;  /* enable timer and fast timer flag clear */
      TSCR2 = 0x00;  /* enable timer ovf interrupt, set prescaler to 1*/
    // ALL on TC 3 as TC0 is used for interrupts  
    TIOS |= 0x08; /* enable OC0 */        //(not necessary)//tc3 
     TC3 = TCNT + 200;   //tc3    
      for(ix = 0; ix < k; ix++) {
             while(!(TFLG1_C3F)); // tc3 
        TC3 += 200; // tc3
      }                                           
      TIOS  &= ~0x08;   /* disable OC0 */  //(not necessary) //tc3 
     
	  /*
  This delay function is taken from the textbook (p383), but adapted
  for my 2MHz bus clock.  
  Consider the period of 1 bus cycle = delta_t = 1/2000000
    Now, consider that 2000 * delta_t would equal 1ms

  >> 1.00ms = delta_t * 2000 << 
  
  Same way realize that we can divide both sides by 100 for precision purposes described @ delay value declaration at the begging of the function.
  >> 10.0us = delta_t * 20 << 
  
  We configure the internal 16-bit timer (TCNT) to start counting and we
  offset the current TCNT by 2000 (1ms) and keep checking until TCNT matches
  this new value.  Each increment of the clock takes 1 delta_t.  Once TCNT has
  incremented by 20 then we have 10us.  Keep counting until k*10us.  
*/
 
}

void delay(unsigned  int kk){ // used in Delay function 
     unsigned  int ix; // counter for interrupt 
     
        counter = 0 ;
               k =kk ; 
      TSCR1 = 0x90;  /* enable timer and fast timer flag clear */
    TIOS |= 0x08; /* enable OC0 */        //(not necessary)//tc3 
   TC3 = TCNT + 200;   //tc3    
 //  TFLG1_C3F = 1; // reset timer
  
      //       TSCR2 = 0x00;
  
      TSCR2 = 0x81;  /* enable timer interrupt, set prescaler to 1*/// TIMER INTERRUPT STARTS 
  

	  
	while ( counter+5 < k );  //  TFLG2_TOF 
	
setInterrupts();                                  
	  
     
}

void SCI_ADC_out (unsigned short ADC_ ){ // OUTPUTS the ADC value passed to it 

if ( flag)  SCI_OutUDec(ADC_ ); // output value thru SCI 
if ( flag)  OutCRLF(); // separate entries 
if ( flag)  PT1AD |=0x01;      // TOGGLE RED LED TO SHOW SERIAL COMMUNICATION IS ACTIVATED ON PIN A1
if ( flag)  Delay(43); // BONNUS1 sampling rate = 440 Hz | 1/440 * 1000 = 2.27 ms = 227 * 10^-5 = 227 * 10 * 10^-6 s = 227 * 10us    
          
          // delayby100us(23); without bonus

  /*
 SCI_OutUDec(ADC_ ); // output value thru SCI 
  OutCRLF(); // separate entries 
PT1AD |=0x01;
 Delay(43); // BONUS1 sampling rate = 440 Hz | 1/440 * 1000 = 2.27 ms = 227 * 10^-5 = 227 * 10 * 10^-6 s = 227 * 10us    
 // delayby100us(23); without bonus 
}                                    */


}