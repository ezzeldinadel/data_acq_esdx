%//*********************************************************************                  
%//*                       McMaster University                         *
%//*                      2DP4 Microprocessors                         *
%//*********************************************************************
%//*********************************************************************
%//*   FINAL PROJECT- Ezzeldin Tahoun- 400043499- tahoune@mcmaster.ca
%//*********************************************************************                  
%
%//***********************************************************************
%// Last Modified to : edit labels
%// by Ezzeldin Tahoun, TIMESTAMP: 11:18 AM 28/03/2016
%//***********************************************************************

clc ; clear % clean matlab !

% SET CONNECTION 
SER=serial('COM5','BaudRate',9600,'Terminator','CR');
% Listen on COM PORT 5 for SCI 
% 9600 bits per second are being transferred on this channel 
% when u see the CR character separate entries 

% Connect 
fopen(SER);

% samples (X AXIS)
t=100;
while 1==1 %1:1000 FINITE!! for infinite loop structure ( continuous data acquisition use 1==1 ) 
    for n=1:t
        graph(n)=str2double(fgetl(SER))*5/(2^8); %fgetl(SER) returns a str each call which is multiplied by ( 5 -0 ) and divided by resolution (2^8) and then converts whole thing to double for improved precision 
        plot(graph); % plot data in graph array of doubles size t 
        fgetl(SER)
        % graph  
        title('ezACQ | Ezzeldin Tahoun'); % title 
        xlabel('Sample'); ylabel('Voltage'); % x-axis and y-axis labels 
        axis([0, t, -2, 7]); %  x-axis limits -2 >> 7  and y-axis limits 0 >> t
        grid % add respective grid 
        drawnow; %draw
    end
end

fclose(s);delete(s);clear s; % ending serial comm to exit  
